GDP_CAP_17 - GDP per capita 2017 (USD)
POP_2019 - population 2019 (absolute)
UNEMPL_18 - unemployment rate 2018 (%)
AVG_SAL_17 - Average Salary 2017 (GEL)